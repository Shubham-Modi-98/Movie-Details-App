package com.example.moviedetails

import android.os.AsyncTask
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_movie_home.*
import org.json.JSONObject
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MovieHomeActivity : AppCompatActivity() {

    lateinit var moviename:String
    lateinit var ak:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_home)

        btnImage.setOnClickListener {
//            var url = "https://www.omdbapi.com/?apikey="+ak+"&t="+moviename
//            moviename = "Parasite"
            moviename = edtMovieName.text.toString()
            ak = "2d0f11a"
            if(moviename == "") {
                Toast.makeText(this@MovieHomeActivity,"Movie Name must be Required",Toast.LENGTH_SHORT).show()
            }
            else {
                var data = Download()
                var url = "https://www.omdbapi.com/?apikey="+ak+"&t="+moviename
                data.execute(url)
            }
        }
    }

    inner class Download : AsyncTask<String,Void,String>() {

        override fun doInBackground(vararg params: String?): String {
            var result =  ""
            var url:URL
            var httpConn:HttpURLConnection
            try {
                url = URL(params[0])
                httpConn = url.openConnection() as HttpURLConnection
                val inputStream = httpConn.inputStream
                val inputStreamReader = InputStreamReader(inputStream)
                var data = inputStreamReader.read()
                while (data > 0) {
                    var character = data.toChar()
                    result += character
                    data = inputStreamReader.read()
                }
                return result
            }
            catch (e:Exception) {
                e.printStackTrace()
                return result
            }
        }

        override fun onPostExecute(result: String?) {
            try {
                var jsonObj = JSONObject(result)
                var poster = jsonObj.getString("Poster")
                var tit =jsonObj.getString("Title")
                var release = jsonObj.getString("Released")
                var gen = jsonObj.getString("Genre")
                var rated = jsonObj.getString("Rated")
                var rtime = jsonObj.getString("Runtime")
                var direct = jsonObj.getString("Director")
                var write = jsonObj.getString("Writer")
                var actor = jsonObj.getString("Actors")
                var plot = jsonObj.getString("Plot")
                var lang = jsonObj.getString("Language")
                var country = jsonObj.getString("Country")
                var award = jsonObj.getString("Awards")
                var imdbrating = jsonObj.getString("imdbRating")
                var imdbvotes = jsonObj.getString("imdbVotes")
                var type = jsonObj.getString("Type")
                var dvd = jsonObj.getString("DVD")
                var box = jsonObj.getString("BoxOffice")
                var prod = jsonObj.getString("Production")

                //SET DATA IN ACTIVITY :
                Glide.with(applicationContext).load(poster).into(movieposter)
                imdbrate.text = "$imdbrating/10"
                movietitle.text = tit
                ratedruntime.text = "$rated / $rtime"
                released.text = release
                genre.text = gen
                movietype.text = type
                awards.text = award
                language.text = "$lang / $country"
                production.text = prod
                actors.text = actor
                director.text = direct
                writer.text = write
                boxoffice.text = box
                votes.text = imdbvotes
                dvddate.text = dvd
                movieplot.text = plot

                println(jsonObj)
            }
            catch (e:Exception) {
                Toast.makeText(this@MovieHomeActivity,"No Movie Found, enter valid Movie Name",Toast.LENGTH_SHORT).show()
            }
            super.onPostExecute(result)
        }
    }
}
