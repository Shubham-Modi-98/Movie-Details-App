package com.example.moviedetails

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Toast
import androidx.annotation.RequiresApi

class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var isConnect = isOnline()
        if(isConnect) {
            Handler().postDelayed({
                var intent1 = Intent(applicationContext,MovieHomeActivity::class.java)
                startActivity(intent1)
                finish()
            },2500)
        }
        else {
            Toast.makeText(applicationContext,"You are Offline, Please connect to the Internet",Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    @RequiresApi(Build.VERSION_CODES.M)
    fun isOnline(): Boolean {
        val connectivityManager =
            applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (connectivityManager != null) {
            val capabilities =
                connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
            if (capabilities != null) {
                return true
            }
        }
        return false
    }
}
